---
published: ture
layout: post
title: "new features: keyboard shortcuts for  pagination"
author: Yu
categories: news
tags:
- Jquery
---

I add a Jquery keyboard shortcuts for pagination in the `gh-pages branch`.

You can press "J" or "left arrow key" to see the older post and press "K" or "right arrow key" to see the newer post.
