---
published: ture
layout: post
title: "add Japanese language"
author: Yu
categories: news
tags:
- Japanese
---

Thanks to [kokeiro](http://kokeiro001.github.io/), now we have a [Japanese language support](https://github.com/yulijia/freshman21/pull/16 "Pull requests") for this theme!

![Imgur](http://i.imgur.com/yRaeWVH.png)
