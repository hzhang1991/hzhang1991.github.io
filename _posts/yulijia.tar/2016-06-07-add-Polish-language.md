---
published: ture
layout: post
title: "add Polish language"
author: Yu
categories: news
tags:
- Polish
---

Thanks to [Derson5](https://github.com/Derson5), now we have a [Polish language support](https://github.com/yulijia/freshman21/pull/17 "Pull requests") for this theme!

![Polish](http://i.imgur.com/DdrAlrw.png)
