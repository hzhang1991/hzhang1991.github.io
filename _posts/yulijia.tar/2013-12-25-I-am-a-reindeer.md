---
published: true
title: I am a reindeer
layout: post
author: Yu
category: articles
tags: 
- reindeer
- sample-post
---


**Santa Claus's reindeer** form an imaginary team of <q>flying reindeer</q> traditionally held to pull the sleigh of Santa Claus <del>and help him deliver Christmas gifts</del>. 
<cite>I fired Santa this year, I didn't need to deliver gifts on the night before Christmas!</cite> 
<code>Oh yeah... oh yeah... oh yeah, my lovely Christmas Eve  `_>` </code>
The commonly cited names of the reindeer are Dasher, Dancer, Prancer, Vixen, Comet, Cupid, Donner, and Blitzen. 
They are based on those used in the 1823 poem "A Visit from St. Nicholas" (commonly called "The Night Before Christmas"), which is arguably the basis of reindeer's popularity as Christmas symbols, and in which Donner and Blitzen were originally called Dunder and Blixem respectively

