---
published: ture
layout: post
title: "Korean and Russian language support"
author: Yu
categories: news
tags:
- Korean
- Russian
---

Thanks to [ulgoon](https://github.com/ulgoon) and [alexeyev](https://github.com/alexeyev).

Now, we have a [Korean language support](https://github.com/yulijia/freshman21/pull/18) and [Russian language support](https://github.com/yulijia/freshman21/pull/19) for this theme!


Korean

![Korean](http://i.imgur.com/z7AAZcp.png)

Russian

![Russian](http://i.imgur.com/woDgrCK.png)
