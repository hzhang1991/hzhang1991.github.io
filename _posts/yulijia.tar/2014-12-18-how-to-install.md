---
layout: post
title: How to install this theme
categories: articles
tags: [sample-post]
comments: true
description: How to install this theme, follow steps, very easy!
---

## How to install Freshman theme?


```bash
# please make sure you have already installed git tools and ruby tools(gem)
$ gem install sass
$ gem install jekyll
$ git clone https://github.com/yulijia/freshman21.git
```

Then, change the folder name to you own github page name, forexample

```bash
 $ mv freshman thisisyouname.github.io
``` 
