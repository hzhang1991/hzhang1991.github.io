---
published: true
title: 红楼 
layout: post
author: H. Zhang
category: note 
tags: [红楼梦]
comments: false
---

---
<iframe width="560" height="315" src="https://www.youtube.com/embed/oyN28NDN3gY" frameborder="0" allowfullscreen></iframe>

### 红楼梦 ###
<iframe src="http://docs.google.com/gview?url=http://club.ntu.edu.tw/~davidhsu/The%20Story%20of%20the%20Stone/001-Stone1/120.pdf&embedded=true" width="650" height="1000" frameborder="2"></iframe>

<!--more-->

### 嵌入PDF显示 ###

<!-- <center><embed src="http://gohom.win/HomPDF/mou.pdf" width="850" height="600"></center>
-->
