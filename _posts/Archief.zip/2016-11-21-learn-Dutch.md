---
published: true
title: Learning Dutch
layout: post
author: H. Zhang
category: tutorial
tags: [Dutch, tutorial]
comments: true
---

---


Teacher: Evrim Akar

Time: Monday, 19:00-21:00

No class on 21 Nov.

<!--more-->
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2451.190534125882!2d5.121361951699922!3d52.09446387532995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c66f4f61dea147%3A0xf7da6b4c774a631f!2sDrift+23%2C+3512+BR+Utrecht!5e0!3m2!1szh-CN!2snl!4v1479750841150" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

----

### Homework 2016.11.14  ###
- Oefening 16 --> tell the time in both ways (the digital way and the normal way) and if possible both in the morning and in the afternoon or at night or in the evening. 
- Oefening 17
- Oefening 30--> this we will repeat in class, learn the meanings of the words before the class! 
- Oefening 31
- Oefening 32
- Woordenlijst Thema 3: learn and repeat the words on page 92 (write them 5 times in your notebook)
- Make one sentence for each word! do the same for Woordenlijst Thema 2 op pagina 60. Send your sentences to me by e-mail!!! 
- Make a small research about Bokbierfestival in Utrecht.
- Oefening 33 

	IMPORTANT: Read page 84, 85 and 86 before the class!!! Write down your questions for the class. We will discuss about them. 
- Pagina 97: learn the meanings of the words on page 97! write the plural forms (check the dictionary for the ones you don't know how to make plural!)

	Do the following exercises and send me your answers! 
[Imgur](http://i.imgur.com/uMQ2hz5.png)
[Imgur](http://i.imgur.com/1wKvyYO.png)

<!-- <center><embed src="http://gohom.win/HomPDF/mou.pdf" width="850" height="600"></center>
-->
