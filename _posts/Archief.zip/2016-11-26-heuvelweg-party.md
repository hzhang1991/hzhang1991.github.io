---
published: true
title: Heuvelweg party
layout: post
author: H. Zhang
category: travel
tags: [skiing]
comments: true 
---

---

----
Route: Utrecht central --> Amsterdam Centraal --> Sloterdijk --> Velsen Zuid, Skiheuvel 

<!--more-->

1. To Zaansse Schans: 
> 桑斯安斯座落的区域属于Zaandam、Koog aan de Zaan、Zaandijk三地合成的Zaanstad市，这块环抱着赞河(Zaan River)的区域，是通过伐木业和造船业发展起来的。桑斯安斯风车村(Zaanse Schans Windmill)是荷兰阿姆斯特丹附近的一座欧洲工业化遗迹博物馆。博物馆展览有从荷兰各地搬迁来的各式风车30多座。另外，也拥有博物馆展示和当年这些风车相关的物品。如今，这里成为了观光客了解荷兰的旅行胜地。手工艺术品作坊、木鞋工厂、奶酪作坊、博物馆、工艺品店等构成了荷兰最具特色的乡村风情。风车村是荷兰著名的旅游地，每年吸引大量游客参观。





<!--嵌入 video 
<iframe height=498 width=510 src="http://player.youku.com/embed/XMTY1MTI3NjMyNA==" frameborder=0 allowfullscreen></iframe>

<embed src="http://player.youku.com/player.php/Type/Folder/Fid/27690810/Ob/1/sid/XMTY1MTI3NjMyNA==/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="always" allowFullScreen="true" mode="transparent" type="application/x-shockwave-flash"></embed>

<video width="480" height="320" controls>
<source src="movie.mp4">
</video>
-->

<!-- insert audio
<audio src="http://sc.111ttt.com/up/mp3/314720/8F9F3E8438FE1581248E92B54A3C0AB5.mp3" controls="controls">
</audio>
-->

<!-- Insert pdf 
<iframe src="/pdf/mou.pdf" style="width:300px; height:100px;" frameborder="0"></iframe>
-->

<!-- insert pdf doc use google view
<iframe src="http://docs.google.com/gview?url=http://platinhom.github.io/pdf/mou.pdf&embedded=true" style="width:800px; height:1000px;" frameborder="0"></iframe>
-->
