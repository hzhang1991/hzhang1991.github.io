---
published: false 
title: Christmas 
layout: post
author: H. Zhang
category: travel 
tags: [Christmas]
comments: true 
---

---

<!--more-->
1. $$\downarrow$$ 冰糖葫芦
![Imgur](http://i.imgur.com/MJajeQ4.jpg)
1. $$\downarrow$$ 红地毯
![Imgur](http://i.imgur.com/iaHmOzs.jpg)
2. $$\downarrow$$ 市场
![Imgur](http://i.imgur.com/IycBi57.jpg)

1. $$\downarrow$$ 温泉
![Imgur](http://i.imgur.com/IMpZZcU.jpg)
![Imgur](http://i.imgur.com/LEkLgZE.jpg)
2. $$\downarrow$$ 红十字
![Imgur](http://i.imgur.com/2s60wQ1.jpg)
3. $$\downarrow$$ 
![Imgur](http://i.imgur.com/xyPvf2N.jpg)
4. $$\downarrow$$ 在难中
![Imgur](http://i.imgur.com/H2m61nw.jpg)

1. $$\downarrow$$ 市场上小房子
![Imgur](http://i.imgur.com/E043YgN.jpg)
2. $$\downarrow$$ 手抖了
![Imgur](http://i.imgur.com/AD8ByAE.jpg)
3. $$\downarrow$$ 魔鬼
![Imgur](http://i.imgur.com/JFGp2AA.jpg)
2. $$\downarrow$$ 天文钟
![Imgur](http://i.imgur.com/ymD079q.jpg)

2. $$\downarrow$$  芝麻开窗
![Imgur](http://i.imgur.com/lcHohDy.jpg)
3. $$\downarrow$$ 门徒现身
![Imgur](http://i.imgur.com/cEr5hJ0.jpg)
![Imgur](http://i.imgur.com/hbi9UK0.jpg)
4. $$\downarrow$$ 圣诞市场 圣诞树
![Imgur](http://i.imgur.com/RpeoEk6.jpg)
![Imgur](http://i.imgur.com/wgvZpfh.jpg)

5. $$\downarrow$$ 哇^_^
![Imgur](http://i.imgur.com/YEN7exi.jpg)
6. $$\downarrow$$ people sea
![Imgur](http://i.imgur.com/IwkYyCQ.jpg)
7. $$\downarrow$$ 9.99 euro
![Imgur](http://i.imgur.com/gB9IGgl.jpg)
8. $$\downarrow$$ 游船
![Imgur](http://i.imgur.com/DbQINAU.jpg)
9. $$\downarrow$$ 河边
![Imgur](http://i.imgur.com/iVIfadA.jpg)
![Imgur](http://i.imgur.com/4t6tFsM.jpg)
<!--20161224-->
1. $$\downarrow$$ 
![Imgur](http://i.imgur.com/cdMikgz.jpg)
<!--20161228-->
2. $$\downarrow$$ 州徽
![Imgur](http://i.imgur.com/M9TA32G.jpg)
![Imgur](http://i.imgur.com/J2qd5h9.jpg)
3. $$\downarrow$$ 大帝
![Imgur](http://i.imgur.com/po6w9u4.jpg?1)
![Imgur](http://i.imgur.com/nmy0TzW.jpg)
4. $$\downarrow$$ 大帝背面
![Imgur](http://i.imgur.com/3U4BlWs.jpg)

4. $$downarrow$$ 三角
![Imgur](http://i.imgur.com/OyYXMpk.jpg)
5. $$downarrow$$ 

<!-- video 
<iframe height=498 width=510 src="http://player.youku.com/embed/XMTY1MTI3NjMyNA==" frameborder=0 allowfullscreen></iframe>

<embed src="http://player.youku.com/player.php/Type/Folder/Fid/27690810/Ob/1/sid/XMTY1MTI3NjMyNA==/v.swf" quality="high" width="480" height="400" align="middle" allowScriptAccess="always" allowFullScreen="true" mode="transparent" type="application/x-shockwave-flash"></embed>

<video width="480" height="320" controls>
<source src="movie.mp4">
</video>
-->

<!-- insert audio
<audio src="http://sc.111ttt.com/up/mp3/314720/8F9F3E8438FE1581248E92B54A3C0AB5.mp3" controls="controls">
</audio>
-->

<!-- Insert pdf 
<iframe src="/pdf/mou.pdf" style="width:300px; height:100px;" frameborder="0"></iframe>
-->

<!-- insert pdf doc use google view
<iframe src="http://docs.google.com/gview?url=http://platinhom.github.io/pdf/mou.pdf&embedded=true" style="width:800px; height:1000px;" frameborder="0"></iframe>
-->
