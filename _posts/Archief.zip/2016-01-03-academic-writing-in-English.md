---
published: false 
title: Academic writing in English
layout: post
author: H. Zhang
category: note 
tags: [Academic writing]
comments: true 
---

---
### Words ###

consistently found, is believed to play a critical role in the onset of *, pose a challenge from the numerical perspective of the *, 
### Phrases  ###

### Sentences ###
- For further details, we would like to refer the interested readers  to the *
- Their most salient feature is a pronounced, * .
<!--more-->
<!-- <center><embed src="http://gohom.win/HomPDF/mou.pdf" width="850" height="600"></center>
-->
